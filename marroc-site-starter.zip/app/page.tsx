import Hero from "@/components/Hero";
import { Section, H2 } from "@/components/Section";
import Link from "next/link";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Section>
        <div className="container grid md:grid-cols-3 gap-6">
          {[
            {title: "Livro", desc:"Ficção mística baseada em vivências reais.", href:"/livros/um-lugar-entre-mundos"},
            {title: "Imersões & Retiros", desc:"Círculos e experiências guiadas.", href:"/agenda"},
            {title: "Live Set Ritual", desc:"Música como portal de cura.", href:"/projetos/mahakarma"}
          ].map((c)=> (
            <div key={c.title} className="card p-6">
              <H2>{c.title}</H2>
              <p className="subtle mt-2">{c.desc}</p>
              <Link className="btn btn-outline mt-6" href={c.href}>Explorar</Link>
            </div>
          ))}
        </div>
      </Section>
      <Section className="bg-white/5">
        <div className="container">
          <H2>Impacto / Partilha</H2>
          <p className="subtle mt-3 max-w-2xl">
            Parte de cada venda sustenta a aldeia que inspirou a obra — transparência trimestral.
          </p>
        </div>
      </Section>
    </>
  );
}
