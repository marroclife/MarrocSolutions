import { Section, H2 } from "@/components/Section";
import Link from "next/link";

export default function ProjetosPage() {
  const projects = [
    { slug: "imersao-conexoes", title: "Imersão Conexões", desc: "Vivência guiada de cura e expressão." },
    { slug: "santuario-urbano", title: "Santuário Urbano", desc: "Espaço de práticas e rituais." },
    { slug: "mahakarma", title: "Banda MahaKarma / Live Set", desc: "Música como tecnologia espiritual." },
    { slug: "role-galaktico", title: "Rolê Galáktico", desc: "Arte, música e sincronicidades." }
  ];
  return (
    <Section>
      <div className="container">
        <H2>Projetos</H2>
        <div className="grid md:grid-cols-2 gap-6 mt-6">
          {projects.map(p => (
            <div key={p.slug} className="card p-6">
              <h3 className="font-display text-2xl">{p.title}</h3>
              <p className="subtle mt-2">{p.desc}</p>
              <Link className="btn btn-outline mt-4" href={`/projetos/${p.slug}`}>Abrir</Link>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
