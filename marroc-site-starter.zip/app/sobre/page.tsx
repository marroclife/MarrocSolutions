import { Section, H2 } from "@/components/Section";

export default function SobrePage() {
  return (
    <Section>
      <div className="container max-w-3xl">
        <H2>Sobre / Imprensa</H2>
        <p className="subtle mt-3">
          Marroc é artista, produtor e guardião de rituais sonoros. Este presskit inclui bio curta/longa, fotos oficiais e contatos.
        </p>
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          <a className="btn btn-outline" href="#" download>Bio (curta)</a>
          <a className="btn btn-outline" href="#" download>Bio (longa)</a>
          <a className="btn btn-outline" href="#" download>Fotos oficiais</a>
        </div>
      </div>
    </Section>
  );
}
