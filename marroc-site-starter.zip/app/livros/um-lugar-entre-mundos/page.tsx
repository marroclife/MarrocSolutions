import Image from "next/image";
import { Section, H2 } from "@/components/Section";

export const metadata = {
  title: "Um Lugar entre Mundos — Samadhi: O Despertar de Sofia",
  description: "Ficção mística inspirada em vivências reais com espiritualidade, medicina da floresta e cura."
};

export default function LivroPage() {
  return (
    <>
      <section className="relative overflow-hidden">
        <Image src="/bg-forest.jpg" alt="Floresta mística" fill className="object-cover opacity-40 -z-10" />
        <div className="container section grid md:grid-cols-[320px,1fr] gap-10 items-center">
          <Image src="/capa-ulm.png" width={320} height={440} alt="Capa do livro" className="rounded-2xl shadow-ritual object-cover" />
          <div>
            <h1 className="h1">Um Lugar Entre Mundos</h1>
            <p className="mt-2 text-lg">Samadhi — O Despertar de Sofia</p>
            <ul className="mt-6 space-y-2 list-disc list-inside subtle">
              <li>Leitura transformadora e ritualística em PDF (acesso imediato).</li>
              <li>Inspirada em vivências reais com espiritualidade e medicina da floresta.</li>
              <li>Parte do valor destinado à aldeia indígena que inspirou a história.</li>
            </ul>
            <div className="mt-6 flex gap-3">
              <a className="btn btn-primary" href="https://pay.hotmart.com/" target="_blank" rel="noreferrer">Comprar (R$ 22,20)</a>
              <a className="btn btn-outline" href="https://pay.hotmart.com/" target="_blank" rel="noreferrer">Valor consciente (R$ 33,30)</a>
            </div>
          </div>
        </div>
      </section>
      <Section>
        <div className="container grid md:grid-cols-2 gap-10">
          <div>
            <H2>Sobre o livro</H2>
            <p className="subtle mt-3">Uma jornada mística de superação, cura e autoconhecimento que acompanha Sofia em sua travessia.</p>
          </div>
          <div className="card p-6">
            <h3 className="font-display text-xl">Garantia incondicional de 7 dias</h3>
            <p className="subtle mt-2">Seu dinheiro de volta sem perguntas até 7 dias após a compra.</p>
          </div>
        </div>
      </Section>
      <Section className="bg-white/5">
        <div className="container">
          <H2>FAQ</H2>
          <div className="mt-4 grid md:grid-cols-2 gap-6">
            {[
              ["Como recebo o PDF?","Por e-mail logo após a confirmação, com acesso imediato."],
              ["Tem garantia?","Sim, 7 dias — devolução sem perguntas."],
              ["Posso ler no celular?","Sim, em qualquer dispositivo."],
              ["Suporte?","Fale comigo no WhatsApp pelo botão de Contato."]
            ].map(([q,a]) => (
              <div key={q} className="card p-6">
                <p className="font-medium">{q}</p>
                <p className="subtle mt-2">{a}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>
    </>
  );
}
