import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        forest: "#0E3B2E",
        ritual: "#0B0B0B",
        gold: "#C7A94B",
        paper: "#F6F5F2"
      },
      boxShadow: {
        ritual: "0 10px 30px rgba(199,169,75,0.15)"
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"]
      }
    },
  },
  plugins: [],
}
export default config
