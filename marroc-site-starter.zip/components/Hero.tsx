import Image from "next/image";
import Link from "next/link";

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <Image
        src="/bg-forest.jpg"
        alt="Floresta mística"
        fill
        className="object-cover opacity-40 -z-10"
        priority
      />
      <div className="container section">
        <div className="max-w-2xl">
          <h1 className="h1">Música, cura e palavra — um hub vivo de portais.</h1>
          <p className="mt-4 subtle">
            Livros, rituais, imersões e sets que alinham arte e espiritualidade.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/livros/um-lugar-entre-mundos" className="btn btn-primary">
              Ler “Um Lugar entre Mundos”
            </Link>
            <Link href="/newsletter" className="btn btn-outline">Assinar Newsletter</Link>
          </div>
        </div>
      </div>
    </section>
  );
}
