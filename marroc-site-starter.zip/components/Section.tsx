export function Section({ children, className = "" }: { children: React.ReactNode, className?: string }) {
  return <section className={`section ${className}`}>{children}</section>;
}
export function H2({ children }: { children: React.ReactNode }) {
  return <h2 className="h2">{children}</h2>;
}
